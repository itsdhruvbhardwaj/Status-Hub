package com.dhruv.status.hub.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri
import com.dhruv.status.hub.utils.*

/**
 * SettingsScreen Composable
 * 
 * Provides a user interface for app settings, including general preferences and app information.
 * 
 * @param onBack Callback for handling back navigation.
 * @param onThemeChange Callback for notifying theme changes (e.g., theme preference switch).
 * @param onHelpClick Callback for navigating to the Help/How to Use screen.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onThemeChange: () -> Unit = {},
    onHelpClick: () -> Unit
) {
    // Current context for accessing preferences and starting activities
    val context = LocalContext.current
    
    // State for toggling auto-save status and theme selection
    var autoSave by remember { mutableStateOf(isAutoSaveEnabled(context)) }
    var currentTheme by remember { mutableStateOf(getAppTheme(context)) }
    var showThemeDialog by remember { mutableStateOf(false) }

    // Handle physical back button presses
    BackHandler { onBack() }

    Scaffold(
        topBar = {
            // Shadowed surface for the TopAppBar
            Surface(shadowElevation = 4.dp) {
                TopAppBar(
                    title = {
                        Text(
                            text = "Settings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 24.sp
                        )
                    },
                    navigationIcon = {
                        // Back navigation button
                        IconButton(onClick = onBack) {
                            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.primaryContainer,
                        titleContentColor = MaterialTheme.colorScheme.onPrimaryContainer,
                        navigationIconContentColor = MaterialTheme.colorScheme.onPrimaryContainer
                    )
                )
            }
        }
    ) { innerPadding ->
        // Main content column with vertical scrolling enabled
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // General Settings Section
            Text(text = "General", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            // Toggle for Auto-Save Status preference
            SettingsToggleItem(
                title = "Auto Save Status",
                subtitle = "Automatically save viewed statuses to gallery",
                checked = autoSave,
                onCheckedChange = {
                    autoSave = it
                    setAutoSaveEnabled(context, it)
                }
            )
            
            HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp), color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))

            // Selection for App Theme (System, Light, Dark)
            SettingsClickableItem(
                title = "App Theme",
                subtitle = when (currentTheme) {
                    THEME_LIGHT -> "Light"
                    THEME_DARK -> "Dark"
                    else -> "System Default"
                },
                onClick = { showThemeDialog = true }
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 16.dp), color = MaterialTheme.colorScheme.outlineVariant)

            // App Information Section
            Text(text = "App Info", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(8.dp))

            // Navigates to help content
            SettingsClickableItem(
                title = "How to Use / Help",
                onClick = onHelpClick
            )

            // Opens Privacy Policy in a browser
            SettingsClickableItem(
                title = "Privacy Policy",
                onClick = {
                    val intent = Intent(Intent.ACTION_VIEW, "http://sites.google.com/view/status-hub-privacy-policy/home".toUri())
                    context.startActivity(intent)
                }
            )

            // Opens system share sheet to share the app link
            SettingsClickableItem(
                title = "Share App",
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "Status Hub App")
                        putExtra(Intent.EXTRA_TEXT, "Check out this amazing Status Saver app! Download it here: https://play.google.com/store/apps/details?id=${context.packageName}")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "Share via"))
                }
            )
        }
    }

    // Theme Selection Dialog
    if (showThemeDialog) {
        AlertDialog(
            onDismissRequest = { showThemeDialog = false },
            containerColor = MaterialTheme.colorScheme.surface,
            title = { Text("Choose Theme", fontWeight = FontWeight.Bold) },
            text = {
                Column {
                    ThemeOptionRow("System Default", currentTheme == THEME_SYSTEM) {
                        currentTheme = THEME_SYSTEM
                        setAppTheme(context, THEME_SYSTEM)
                        onThemeChange()
                        showThemeDialog = false
                    }
                    ThemeOptionRow("Light", currentTheme == THEME_LIGHT) {
                        currentTheme = THEME_LIGHT
                        setAppTheme(context, THEME_LIGHT)
                        onThemeChange()
                        showThemeDialog = false
                    }
                    ThemeOptionRow("Dark", currentTheme == THEME_DARK) {
                        currentTheme = THEME_DARK
                        setAppTheme(context, THEME_DARK)
                        onThemeChange()
                        showThemeDialog = false
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showThemeDialog = false }) {
                    Text("Cancel")
                }
            },
            shape = RoundedCornerShape(28.dp)
        )
    }
}

/**
 * Reusable row for theme options in the dialog
 */
@Composable
fun ThemeOptionRow(
    title: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 0.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RadioButton(selected = isSelected, onClick = onClick)
        Spacer(modifier = Modifier.width(8.dp))
        Text(text = title, fontSize = 16.sp)
    }
}

/**
 * SettingsToggleItem
 * 
 * A reusable row component with a title, subtitle, and a Switch.
 */
@Composable
fun SettingsToggleItem(
    title: String,
    subtitle: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit
) {
    // Determine if the app is currently in dark theme
    val context = LocalContext.current
    val themePref = getAppTheme(context)
    val isDark = when (themePref) {
        THEME_LIGHT -> false
        THEME_DARK -> true
        else -> isSystemInDarkTheme()
    }
    val blueColor = Color(0xFF3F5AA9)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = title, fontSize = 16.sp, fontWeight = FontWeight.Normal, color = MaterialTheme.colorScheme.onBackground)
            Text(text = subtitle, fontSize = 12.sp, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f))
        }
        // Switch for boolean settings
        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            modifier = Modifier.scale(0.7f),
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = if (isDark) blueColor else Color.Black,
                uncheckedThumbColor = Color.White,
                uncheckedTrackColor = Color.LightGray,
                uncheckedBorderColor = Color.Transparent
            )
        )
    }
}

/**
 * SettingsClickableItem
 * 
 * A reusable row component for navigation or triggering actions.
 */
@Composable
fun SettingsClickableItem(
    title: String,
    subtitle: String? = null,
    onClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp)
    ) {
        Text(
            text = title,
            fontSize = 16.sp,
            fontWeight = FontWeight.Normal,
            color = MaterialTheme.colorScheme.onBackground
        )
        if (subtitle != null) {
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.6f)
            )
        }
    }
}
