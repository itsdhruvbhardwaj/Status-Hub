package com.dhruv.status.hub.utils

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.util.Log
import com.dhruv.status.hub.data.DownloadDatabase
import com.dhruv.status.hub.data.DownloadRecord
import com.dhruv.status.hub.utils.extractors.FacebookExtractor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.delay
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicLong

/**
 * Central manager for all downloads in Status Hub.
 * Enhanced for robust MP4 downloads, DASH muxing, and Gallery playability.
 * Fixes "stuck at 100%" by correctly handling finalization and ensuring no infinite retry loops.
 */
object DownloadManager {

    private const val TAG = "DownloadManager"
    private const val MAX_CONCURRENT = 3
    private const val VIDEO_CHUNKS = 4
    private const val RETRIES_BEFORE_WAIT = 3
    private const val INITIAL_RETRY_DELAY_MS = 2_000L
    private const val MAX_RETRY_DELAY_MS = 30_000L
    private const val BUFFER_SIZE = 131_072

    private val scope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val activeJobs = ConcurrentHashMap<Long, Job>()
    private val runningIds = ConcurrentHashMap.newKeySet<Long>()
    private val isInitialized = AtomicBoolean(false)

    private val _downloadSpeeds = MutableStateFlow<Map<Long, Long>>(emptyMap())
    val downloadSpeeds = _downloadSpeeds.asStateFlow()

    private val client = OkHttpClient.Builder()
        .followRedirects(true).followSslRedirects(true)
        .connectTimeout(30, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).writeTimeout(30, TimeUnit.SECONDS)
        .build()

    fun init(context: Context) {
        if (!isInitialized.compareAndSet(false, true)) return
        val appContext = context.applicationContext
        registerNetworkCallback(appContext)
        scope.launch {
            val db = DownloadDatabase.getDatabase(appContext)
            db.downloadDao().getDownloadsByStatus("DOWNLOADING").forEach { db.downloadDao().updateRecord(it.copy(status = "QUEUED")) }
            db.downloadDao().getDownloadsByStatus("PROCESSING").forEach { db.downloadDao().updateRecord(it.copy(status = "QUEUED")) }
            processQueue(appContext)
        }
    }

    private fun registerNetworkCallback(context: Context) {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        try {
            val request = NetworkRequest.Builder().addCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET).build()
            cm.registerNetworkCallback(request, object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(network: Network) { processQueue(context) }
            })
        } catch (e: Exception) { Log.e(TAG, "Network callback failed", e) }
    }

    fun enqueue(context: Context, record: DownloadRecord) {
        scope.launch {
            DownloadDatabase.getDatabase(context).downloadDao().insertRecord(record)
            startService(context); processQueue(context)
        }
    }

    fun resume(context: Context, id: Long) {
        scope.launch {
            val db = DownloadDatabase.getDatabase(context)
            val record = db.downloadDao().getRecordById(id) ?: return@launch
            db.downloadDao().updateRecord(record.copy(status = "QUEUED", errorMessage = null))
            startService(context); processQueue(context)
        }
    }

    fun pause(context: Context, id: Long) {
        activeJobs[id]?.cancel(); activeJobs.remove(id); updateSpeed(id, 0L)
        scope.launch {
            val db = DownloadDatabase.getDatabase(context)
            val record = db.downloadDao().getRecordById(id) ?: return@launch
            db.downloadDao().updateRecord(record.copy(status = "PAUSED"))
            processQueue(context)
        }
    }

    fun cancel(context: Context, id: Long) {
        activeJobs[id]?.cancel(); activeJobs.remove(id); updateSpeed(id, 0L)
        scope.launch {
            val db = DownloadDatabase.getDatabase(context)
            val record = db.downloadDao().getRecordById(id) ?: return@launch
            deleteTemporaryFiles(context, record)
            db.downloadDao().deleteRecord(record)
            processQueue(context)
        }
    }

    private fun deleteTemporaryFiles(context: Context, record: DownloadRecord) {
        File(context.cacheDir, "temp_${record.id}_${record.fileName}").delete()
        File(context.cacheDir, "dash_v_${record.id}_${record.fileName}").delete()
        File(context.cacheDir, "dash_a_${record.id}_${record.fileName}").delete()
        for (i in 0 until VIDEO_CHUNKS) File(context.cacheDir, "dash_v_${record.id}_chunk_$i").delete()
    }

    private fun updateSpeed(id: Long, speed: Long) {
        val current = _downloadSpeeds.value.toMutableMap()
        if (speed <= 0L) current.remove(id) else current[id] = speed
        _downloadSpeeds.value = current
    }

    private fun startService(context: Context) {
        val intent = Intent(context, DownloadService::class.java)
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) context.startForegroundService(intent)
        else context.startService(intent)
    }

    private fun processQueue(context: Context) {
        scope.launch {
            val db = DownloadDatabase.getDatabase(context)
            val active = db.downloadDao().getCountByStatus("DOWNLOADING") + db.downloadDao().getCountByStatus("PROCESSING")
            val availableSlots = MAX_CONCURRENT - active
            if (availableSlots > 0) db.downloadDao().getNextQueued(availableSlots).forEach { startDownload(context, it) }
        }
    }

    private fun applyPlatformHeaders(builder: Request.Builder, platform: String) {
        val browserUA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
        builder.header("User-Agent", browserUA)
        val low = platform.lowercase()
        if (low.contains("facebook")) builder.header("Referer", "https://www.facebook.com/")
        if (low.contains("instagram")) builder.header("Referer", "https://www.instagram.com/")
    }

    private fun startDownload(context: Context, record: DownloadRecord) {
        val id = record.id
        if (!runningIds.add(id)) return
        val job = scope.launch {
            val db = DownloadDatabase.getDatabase(context)
            try {
                val initialRecord = db.downloadDao().getRecordById(id) ?: return@launch
                db.downloadDao().updateRecord(initialRecord.copy(status = "DOWNLOADING", errorMessage = null))
                val sharedProgress = AtomicLong(initialRecord.downloadedBytes)
                val sharedSpeed = AtomicLong(0L)
                val monitorJob = launch {
                    var lastTime = System.currentTimeMillis()
                    while (isActive) {
                        delay(1_000L); val now = System.currentTimeMillis(); val bytes = sharedSpeed.getAndSet(0L)
                        val elapsed = now - lastTime
                        if (elapsed > 0L) updateSpeed(id, bytes * 1000L / elapsed)
                        lastTime = now
                        db.downloadDao().updateProgress(id, sharedProgress.get())
                    }
                }
                var completed = false; var lastError: Exception? = null; var retryAttempt = 0; var retryDelay = INITIAL_RETRY_DELAY_MS
                while (isActive && !completed) {
                    val freshRecord = db.downloadDao().getRecordById(id) ?: break
                    if (freshRecord.status == "PAUSED" || freshRecord.status == "CANCELLED") break
                    try {
                        refreshProgressFromDisk(context, freshRecord, sharedProgress)
                        if (freshRecord.dashAudioUrl != null) performDashDownload(context, id, sharedProgress, sharedSpeed)
                        else performSingleDownload(context, id, sharedProgress, sharedSpeed)
                        completed = true
                    } catch (e: Exception) {
                        if (e is CancellationException) throw e
                        if (e is UnrecoverableException) { lastError = e; break }
                        lastError = e; retryAttempt++; delay(retryDelay)
                        retryDelay = minOf(retryDelay * 2L, MAX_RETRY_DELAY_MS)
                        if (retryAttempt >= RETRIES_BEFORE_WAIT) { retryAttempt = 0; retryDelay = INITIAL_RETRY_DELAY_MS; delay(3000) }
                    }
                }
                if (!completed && isActive) {
                    val final = db.downloadDao().getRecordById(id)
                    if (final != null && final.status != "PAUSED" && final.status != "CANCELLED") {
                        db.downloadDao().updateRecord(final.copy(status = "FAILED", errorMessage = lastError?.message ?: "Failed"))
                    }
                }
                monitorJob.cancel()
            } finally {
                activeJobs.remove(id); runningIds.remove(id); updateSpeed(id, 0L); processQueue(context)
            }
        }
        activeJobs[id] = job
    }

    private fun refreshProgressFromDisk(context: Context, record: DownloadRecord, progress: AtomicLong) {
        if (record.dashAudioUrl != null) {
            val audio = File(context.cacheDir, "dash_a_${record.id}_${record.fileName}")
            val video = File(context.cacheDir, "dash_v_${record.id}_${record.fileName}")
            var done = if (video.exists()) video.length() else {
                var total = 0L
                for (i in 0 until VIDEO_CHUNKS) {
                    val f = File(context.cacheDir, "dash_v_${record.id}_chunk_$i")
                    if (f.exists()) total += f.length()
                }
                total
            }
            if (audio.exists()) done += audio.length()
            progress.set(done)
        } else progress.set(File(context.cacheDir, "temp_${record.id}_${record.fileName}").let { if (it.exists()) it.length() else 0L })
    }

    private suspend fun performSingleDownload(
        context: Context,
        id: Long,
        progress: AtomicLong,
        speed: AtomicLong
    ) = withContext(Dispatchers.IO) {
        val db = DownloadDatabase.getDatabase(context)
        val record = db.downloadDao().getRecordById(id) ?: return@withContext
        val downloadUrl = record.downloadUrl
            ?: throw UnrecoverableException("Download URL is missing.")

        val tempFile = File(
            context.cacheDir,
            "temp_${id}_${record.fileName}"
        )

        /*
         * Facebook progressive URLs are already complete media resources.
         * Do NOT reconstruct them using our generic range downloader.
         *
         * Facebook CDNs may return different range semantics (including
         * capped/redirected ranges). A range-size probe followed by a large
         * Range request can therefore produce a file with the right-looking
         * byte count but the wrong bytes. For Facebook we stream one normal
         * GET response and preserve the response body byte-for-byte.
         *
         * Other platforms keep the existing resumable/range implementation.
         */
        if (record.platform.equals("Facebook", ignoreCase = true)) {
            downloadFacebookProgressive(
                context = context,
                id = id,
                record = record,
                url = downloadUrl,
                tempFile = tempFile,
                progress = progress,
                speed = speed
            )
            return@withContext
        }

        val size = getStreamSize(downloadUrl, record.platform)
        if (tempFile.exists() && tempFile.length() > size) {
            tempFile.delete()
        }

        val offset = if (tempFile.exists()) tempFile.length() else 0L
        progress.set(offset)
        db.downloadDao().updateRecord(
            record.copy(
                totalBytes = size,
                downloadedBytes = offset
            )
        )

        if (offset < size) {
            downloadStreamSegment(
                downloadUrl,
                tempFile,
                offset,
                size - 1L,
                progress,
                speed,
                0L,
                record.platform
            )
        }

        if (tempFile.length() != size) {
            throw IOException(
                "Download incomplete: ${tempFile.length()}/$size"
            )
        }

        finishSingleDownload(
            context = context,
            id = id,
            record = record,
            tempFile = tempFile,
            totalSize = size
        )
    }

    /**
     * Facebook progressive downloads are handled separately from generic
     * range downloads.
     *
     * The URL extracted from Facebook is a signed/temporary CDN URL. By the
     * time the user starts the download it can already be stale. Therefore we
     * always refresh the source page immediately before downloading and try
     * the freshly extracted URLs first. The original URL is kept as a fallback.
     *
     * We also never treat HTTP status/byte count alone as proof of a video.
     * The response is checked before anything is committed as the downloaded
     * file, and the response body is copied byte-for-byte without remuxing.
     */
    private suspend fun downloadFacebookProgressive(
        context: Context,
        id: Long,
        record: DownloadRecord,
        url: String,
        tempFile: File,
        progress: AtomicLong,
        speed: AtomicLong
    ) = withContext(Dispatchers.IO) {

        val candidates = LinkedHashSet<String>()
        if (url.isNotBlank()) candidates.add(url)

        // Refresh the Facebook page now. This is the critical part: do not
        // rely on a CDN URL captured several seconds/minutes ago during Analyze.
        try {
            val refreshed = FacebookExtractor(client).extract(record.sourceUrl)
            if (refreshed != null) {
                refreshed.formats.forEach { format ->
                    if (!format.isAudio && format.url.isNotBlank()) {
                        candidates.add(format.url)
                    }
                }
                if (refreshed.url.isNotBlank()) candidates.add(refreshed.url)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Facebook URL refresh failed; trying original URL", e)
        }

        if (candidates.isEmpty()) {
            throw UnrecoverableException("Could not extract a Facebook video URL.")
        }

        var lastError: IOException? = null

        // Try a small number of fresh candidates. Facebook pages frequently
        // expose more than one representation; one can be stale while another
        // is still valid.
        for (candidate in candidates.take(6)) {
            currentCoroutineContext().ensureActive()

            try {
                downloadFacebookResponse(
                    context = context,
                    id = id,
                    record = record,
                    url = candidate,
                    tempFile = tempFile,
                    progress = progress,
                    speed = speed
                )
                return@withContext
            } catch (e: CancellationException) {
                throw e
            } catch (e: IOException) {
                lastError = e
                Log.w(TAG, "Facebook candidate failed: ${e.message}")
                tempFile.delete()
                File(
                    context.cacheDir,
                    "temp_${id}_${record.fileName}.part"
                ).delete()
            }
        }

        throw UnrecoverableException(
            lastError?.message ?: "Facebook video could not be downloaded."
        )
    }

    /** Download one Facebook progressive resource, preserving its bytes. */
    private suspend fun downloadFacebookResponse(
        context: Context,
        id: Long,
        record: DownloadRecord,
        url: String,
        tempFile: File,
        progress: AtomicLong,
        speed: AtomicLong
    ) = withContext(Dispatchers.IO) {

        val db = DownloadDatabase.getDatabase(context)
        val partFile = File(
            context.cacheDir,
            "temp_${id}_${record.fileName}.part"
        )

        partFile.delete()
        tempFile.delete()
        progress.set(0L)

        var nextOffset = 0L
        var totalSize = -1L
        var firstRequest = true

        while (true) {
            currentCoroutineContext().ensureActive()

            val builder = Request.Builder()
                .url(url)
                .header(
                    "User-Agent",
                    "Mozilla/5.0 (Linux; Android 13; Pixel 7) " +
                            "AppleWebKit/537.36 (KHTML, like Gecko) " +
                            "Chrome/121.0.0.0 Mobile Safari/537.36"
                )
                .header("Accept", "video/mp4,video/*,application/octet-stream;q=0.9,*/*;q=0.5")
                .header("Accept-Language", "en-US,en;q=0.9")
                .header("Referer", "https://www.facebook.com/")
                .header("Origin", "https://www.facebook.com")
                .header("Sec-Fetch-Dest", "video")
                .header("Sec-Fetch-Mode", "cors")
                .header("Sec-Fetch-Site", "same-site")
                .header("Accept-Encoding", "identity")
                .header("Cache-Control", "no-cache")

            if (!firstRequest) {
                builder.header("Range", "bytes=$nextOffset-")
            }

            client.newCall(builder.build()).execute().use { response ->
                if (!response.isSuccessful) {
                    throw IOException("Facebook video HTTP ${response.code}")
                }

                val contentType = response.header("Content-Type")
                    ?.substringBefore(';')
                    ?.trim()
                    ?.lowercase()
                    ?: ""

                val body = response.body
                    ?: throw IOException("Facebook returned an empty response body")

                val contentLength = body.contentLength()
                val contentRange = response.header("Content-Range")

                var responseStart = nextOffset
                var responseEnd = -1L
                var responseTotal = -1L
                var responseWritten = 0L

                if (response.code == 206) {
                    val match = Regex(
                        """bytes\s+(\d+)-(\d+)/(\d+|\*)""",
                        RegexOption.IGNORE_CASE
                    ).find(contentRange.orEmpty())
                        ?: throw IOException("Facebook returned 206 without Content-Range")

                    responseStart = match.groupValues[1].toLongOrNull()
                        ?: throw IOException("Invalid Facebook range start")
                    responseEnd = match.groupValues[2].toLongOrNull()
                        ?: throw IOException("Invalid Facebook range end")
                    responseTotal = match.groupValues[3].toLongOrNull() ?: -1L

                    if (responseStart != nextOffset) {
                        throw IOException(
                            "Facebook returned range $responseStart-$responseEnd; expected start $nextOffset"
                        )
                    }
                } else if (response.code != 200) {
                    throw IOException("Unexpected Facebook HTTP ${response.code}")
                } else if (!firstRequest && nextOffset > 0L) {
                    throw IOException("Facebook CDN ignored continuation range")
                }

                if (responseTotal > 0L) {
                    totalSize = responseTotal
                } else if (response.code == 200 && contentLength > 0L) {
                    totalSize = contentLength
                }

                /*
                 * Reject error/login pages before writing them as a video.
                 * Do not rely on Content-Type alone because some Facebook
                 * responses are served as application/octet-stream.
                 */
                val obviouslyText = contentType.startsWith("text/") ||
                        contentType.contains("html") ||
                        contentType.contains("json") ||
                        contentType.contains("xml")

                if (obviouslyText) {
                    throw IOException("Facebook returned an error page instead of video.")
                }

                partFile.parentFile?.mkdirs()
                RandomAccessFile(partFile, "rw").use { raf ->
                    raf.seek(responseStart)

                    body.byteStream().use { input ->
                        val buffer = ByteArray(BUFFER_SIZE)
                        var written = 0L
                        var sniffed = false
                        val sniff = ByteArray(64)
                        var sniffCount = 0

                        while (true) {
                            currentCoroutineContext().ensureActive()
                            val read = input.read(buffer)
                            if (read < 0) break
                            if (read == 0) continue

                            if (!sniffed && sniffCount < sniff.size) {
                                val copy = minOf(read, sniff.size - sniffCount)
                                System.arraycopy(buffer, 0, sniff, sniffCount, copy)
                                sniffCount += copy
                                if (sniffCount >= 12) {
                                    sniffed = true
                                }
                            }

                            raf.write(buffer, 0, read)
                            written += read.toLong()

                            progress.set(responseStart + written)
                            speed.addAndGet(read.toLong())
                        }

                        if (written <= 0L) {
                            throw IOException("Facebook returned an empty video response")
                        }
                        responseWritten = written

                        if (contentLength > 0L && written != contentLength) {
                            throw IOException(
                                "Facebook response truncated: $written/$contentLength"
                            )
                        }

                        if (contentType.isBlank() || contentType == "application/octet-stream") {
                            val prefix = String(sniff, 0, sniffCount, Charsets.US_ASCII).lowercase()
                            val hasMp4Box = prefix.contains("ftyp") ||
                                    prefix.contains("styp") ||
                                    prefix.contains("moov") ||
                                    prefix.contains("mdat")
                            if (prefix.contains("<html") || prefix.contains("<!doctype") ||
                                prefix.contains("{\"error") || prefix.contains("{\"message")) {
                                throw IOException("Facebook returned an error page instead of video.")
                            }
                            if (!hasMp4Box && contentType.isBlank()) {
                                // Do not reject a legitimate binary response merely
                                // because Facebook omitted Content-Type; the final
                                // media validation below is authoritative.
                                Log.w(TAG, "Facebook response has no Content-Type; accepting binary body for final validation")
                            }
                        }
                    }
                }

                nextOffset = if (response.code == 206 && responseEnd >= responseStart) {
                    responseEnd + 1L
                } else {
                    responseStart + if (contentLength > 0L) contentLength else responseWritten
                }

                if (response.code == 200) {
                    totalSize = nextOffset
                }

                if (totalSize > 0L && nextOffset >= totalSize) {
                    return@use
                }

                if (response.code == 206) {
                    if (nextOffset <= responseStart) {
                        throw IOException("Facebook partial response made no progress")
                    }
                    firstRequest = false
                } else {
                    throw IOException("Facebook response ended before the complete video")
                }
            }

            if (totalSize > 0L && nextOffset >= totalSize) break
        }

        if (!partFile.exists() || partFile.length() <= 0L) {
            throw IOException("Facebook video file was not created")
        }

        if (totalSize > 0L && partFile.length() != totalSize) {
            throw IOException("Facebook video incomplete: ${partFile.length()}/$totalSize")
        }

        if (!partFile.renameTo(tempFile)) {
            partFile.inputStream().use { input ->
                tempFile.outputStream().use { output -> input.copyTo(output) }
            }
            partFile.delete()
        }

        val actualSize = tempFile.length()
        if (actualSize <= 0L) throw IOException("Facebook video file is empty")
        progress.set(actualSize)

        finishSingleDownload(
            context = context,
            id = id,
            record = record,
            tempFile = tempFile,
            totalSize = actualSize
        )
    }

    private suspend fun finishSingleDownload(
        context: Context,
        id: Long,
        record: DownloadRecord,
        tempFile: File,
        totalSize: Long
    ) {
        val db = DownloadDatabase.getDatabase(context)

        if (!tempFile.exists() || tempFile.length() <= 0L) {
            throw UnrecoverableException("Downloaded media file is empty.")
        }

        db.downloadDao().updateRecord(
            db.downloadDao().getRecordById(id)!!.copy(
                status = "PROCESSING",
                totalBytes = totalSize,
                downloadedBytes = totalSize
            )
        )

        if (!FileUtils.verifyMediaIntegrity(tempFile, record.mediaType)) {
            throw UnrecoverableException("Corrupted media file detected.")
        }

        // Progressive Facebook MP4s must be copied unchanged. They are not
        // DASH fragments and must not be passed through MediaMuxer.
        val uri = FileUtils.saveTempFileToMediaStore(
            context,
            tempFile,
            record.fileName,
            record.mediaType,
            needsRemux = false
        )

        if (uri != null) {
            db.downloadDao().updateRecord(
                db.downloadDao().getRecordById(id)!!.copy(
                    status = "COMPLETED",
                    fileUri = uri.toString(),
                    timestamp = System.currentTimeMillis(),
                    totalBytes = totalSize,
                    downloadedBytes = totalSize
                )
            )
            tempFile.delete()
        } else {
            throw UnrecoverableException(
                "Failed to save media to Gallery."
            )
        }
    }

    private suspend fun performDashDownload(context: Context, id: Long, progress: AtomicLong, speed: AtomicLong) = withContext(Dispatchers.IO) {
        val db = DownloadDatabase.getDatabase(context)
        val record = db.downloadDao().getRecordById(id) ?: return@withContext
        val videoUrl = record.downloadUrl ?: throw UnrecoverableException("Video URL missing")
        val audioUrl = record.dashAudioUrl ?: throw UnrecoverableException("Audio URL missing")

        val videoSize = getStreamSize(videoUrl, record.platform)
        val audioSize = getStreamSize(audioUrl, record.platform)
        val videoFinal = File(context.cacheDir, "dash_v_${id}_${record.fileName}")
        val audioFile = File(context.cacheDir, "dash_a_${id}_${record.fileName}")
        val tempFinal = File(context.cacheDir, "temp_${id}_${record.fileName}")
        val chunkSize = (videoSize + VIDEO_CHUNKS - 1L) / VIDEO_CHUNKS
        val chunks = (0 until VIDEO_CHUNKS).map { File(context.cacheDir, "dash_v_${id}_chunk_$it") }

        coroutineScope {
            if (!(videoFinal.exists() && videoFinal.length() == videoSize)) {
                chunks.forEachIndexed { i, f ->
                    val start = i * chunkSize; val end = minOf(videoSize - 1L, start + chunkSize - 1L)
                    if (start <= end) launch {
                        val off = if (f.exists()) f.length() else 0L
                        if (off < (end - start + 1L)) downloadStreamSegment(videoUrl, f, off, end, progress, speed, start, record.platform)
                    }
                }
            }
            launch {
                val off = if (audioFile.exists()) audioFile.length() else 0L
                if (off < audioSize) downloadStreamSegment(audioUrl, audioFile, off, audioSize - 1L, progress, speed, 0L, record.platform)
            }
        }
        if (!videoFinal.exists()) videoFinal.outputStream().use { out -> chunks.forEach { it.inputStream().use { input -> input.copyTo(out) }; it.delete() } }
        if (videoFinal.length() != videoSize || audioFile.length() != audioSize) throw IOException("Incomplete DASH streams")

        db.downloadDao().updateRecord(db.downloadDao().getRecordById(id)!!.copy(status = "PROCESSING"))

        if (FileUtils.muxVideoAudio(videoFinal, audioFile, tempFinal)) {
            // Already muxed into standard MP4 by FileUtils.muxVideoAudio, no need to remux again in save function
            val uri = FileUtils.saveTempFileToMediaStore(context, tempFinal, record.fileName, record.mediaType, needsRemux = false)
            if (uri != null) {
                db.downloadDao().updateRecord(db.downloadDao().getRecordById(id)!!.copy(status = "COMPLETED", fileUri = uri.toString(), timestamp = System.currentTimeMillis()))
                videoFinal.delete(); audioFile.delete(); tempFinal.delete()
            } else throw UnrecoverableException("Failed to save merged media.")
        } else throw UnrecoverableException("DASH Muxing failed to produce a valid file.")
    }

    private suspend fun downloadStreamSegment(url: String, file: File, offset: Long, end: Long, progress: AtomicLong, speed: AtomicLong, chunkStart: Long, platform: String) {
        val absStart = chunkStart + offset
        if (absStart > end) return
        val expectedSize = end - absStart + 1L
        val builder = Request.Builder().url(url).header("Range", "bytes=$absStart-$end")
        applyPlatformHeaders(builder, platform)
        client.newCall(builder.build()).execute().use { response ->
            if (response.code != 206 && response.code != 200) throw IOException("HTTP error ${response.code}")
            val isPartial = response.code == 206
            var writeOffset = offset; var toRead = expectedSize
            if (offset > 0L && !isPartial) {
                progress.addAndGet(-offset); writeOffset = 0L; toRead = end - chunkStart + 1L
            }
            RandomAccessFile(file, "rw").use { raf ->
                if (writeOffset == 0L) raf.setLength(0L)
                raf.seek(writeOffset)
                val buffer = ByteArray(BUFFER_SIZE); var written = 0L
                response.body?.byteStream()?.use { input ->
                    while (true) {
                        currentCoroutineContext().ensureActive()
                        val read = input.read(buffer)
                        if (read == -1) break
                        val remaining = toRead - written
                        if (remaining <= 0L) break
                        val actualWrite = minOf(read.toLong(), remaining).toInt()
                        raf.write(buffer, 0, actualWrite); written += actualWrite
                        progress.addAndGet(actualWrite.toLong()); speed.addAndGet(actualWrite.toLong())
                    }
                } ?: throw IOException("Empty response body")
            }
        }
    }

    private suspend fun getStreamSize(url: String, platform: String): Long = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(url).header("Range", "bytes=0-0")
        applyPlatformHeaders(builder, platform)
        try {
            client.newCall(builder.build()).execute().use { r ->
                if (r.isSuccessful) {
                    r.header("Content-Range")?.substringAfterLast("/")?.toLongOrNull()?.let { return@withContext it }
                    if (r.code == 200) r.header("Content-Length")?.toLongOrNull()?.let { return@withContext it }
                }
            }
        } catch (e: Exception) {}
        throw IOException("Could not determine file size from server.")
    }

    private class UnrecoverableException(message: String) : IOException(message)
}